GOVERNING CONSTRAINT CUP: water allocation (relative margin 0.00)
GOVERNING CONSTRAINT ANNEX: electrical capacity (relative margin 0.00)
GOVERNING CONSTRAINT LAB: roof area (relative margin 0.00)

CONFLICT 1: ADOPTED UFC 3-410-01 Section 5.2 | SET ASIDE UFC 3-400-02 Cancelled
CONFLICT 2: ADOPTED GSA PBS-P100 Paragraph 5.3.2 | SET ASIDE UFC 3-400-02 Cancelled
CONFLICT 3: ADOPTED UFM 3-230-13 Section 4.1 | SET ASIDE UFC 3-230-13 Superseded
