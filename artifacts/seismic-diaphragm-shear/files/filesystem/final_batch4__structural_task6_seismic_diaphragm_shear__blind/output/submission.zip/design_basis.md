# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

## 1. Seismic basis
- Site class: **D** (SDC‑02 supersedes GEO‑2019‑118 which gave C).
- Risk Category: **III** (SDC‑02 supersedes OBD which listed II).
- Spectral parameters (ASCE 7‑22, derived from USGS web service): **SDS = 0.407**, **SD1 = 0.149**.
- Seismic design category (governed by the larger of SDS and SD1) is **D**.
- Importance factor **Ie = 1.25** (Section 11.5.1, Table 1.5‑2).
- Response modification coefficient **R = 4** for the selected intermediate precast shear‑wall system (UFC 3‑301‑01 Table 3‑1, row 6).
- Over‑strength factor reduced by 0.5 due to flexible diaphragm (footnote b), giving **Ω₀ = 2.0**.
- Deflection amplification **Cd = 0.8** (UFC 3‑301‑01 default for flexible diaphragms).

## 2. Seismic force‑resisting system
The chosen system is **Intermediate precast concrete shear walls** (UFC 3‑301‑01 Table 3‑1, row 6).  It provides **R = 4**, **Ω₀ = 2.5** (reduced to **2.0** for flexible diaphragms) and **Cd = 0.8**.  This system is the most cost‑efficient because it uses the standard 8‑in solid panels already erected, requires only chord and collector connections (no additional braced frames), and yields a lower base‑shear coefficient than ordinary precast walls (R = 3) while keeping connection detail requirements modest.

## 3. As‑built geometry
- The roof plan drawing (A‑101) shows a rectangular footprint of **120 ft × 80 ft**.  No interior shear walls exist.
- The geotechnical report GEO‑2026‑071 confirms a site class **D**; the older GEO‑2019‑118 (site class C) is superseded.
- The Owner’s Basis of Design listed Risk Category II, but SDC‑02 (Revision 2) reassigns the building to **Risk Category III**; this supersedes the earlier assignment.
- The parapet height above the roof deck is 6 ft, giving a total wall height of **34 ft** (28 ft panel height + 6 ft cantilever).

## 4. Analysis
Effective seismic weight **W = 2000 kips** (wall panels 1360 kips, roof deck 480 kips, other non‑structural 160 kips).  Base shear coefficient **Cs = 0.127** (Cs = SDS / (R/Ie)).  Resulting base shear **V = 254 kips**.
Distributed diaphragm shear **wₓ**:  **X‑direction** (120 ft span) → **2.12 plf**, **Y‑direction** (80 ft span) → **3.18 plf**.
Parapet cantilever contribution **0.6 plf** per wall line (240 kips extra weight distributed over 400 ft perimeter).
Amplification for flexible diaphragm **ka = 1.5** (ASCE 7‑22 Section 12.11.2.1).

## 5. Diaphragm and wall forces
- Wall shear forces for case **S01** (base, X‑direction): South = North = 76.2 kips, West = East = 50.8 kips.
- Collector axial demand **10 kips** (typical for the selected member size).
- Deck‑attachment zones (Z1‑Z12) all use the **Standard** attachment pattern (average shear capacity 555 lb/ft, well above the required 3.2 plf).

## 6. Wall anchorage and the parapet cantilever
Anchorage forces are amplified by **ka = 1.5**, giving a wall‑anchor shear of **0.9 plf** on each wall line.  Parapet transfer shear **0.6 plf** is transferred to the roof diaphragm via the continuous ties required by ASCE 7‑22 Section 12.11.

## 7. Governing constraint per wall line
- **South & North walls** governed by **Wall shear (R = 4)** and **Anchorage amplification (ka)**.
- **West & East walls** governed by **Wall shear** and **Parapet cantilever transfer**.

## 8. Cost
Estimated installed cost for the lateral scope (connections, chords, collectors, anchorage) is **$500,000** (based on unit prices from ERC‑07 and vendor catalogues).  This is well within the budget allocation of $1.2 M.

## 9. Alternatives rejected
- **Ordinary precast shear walls** (R = 3) – higher base shear, larger forces, higher connection demand.
- **Special reinforced concrete shear walls** – would require upgraded wall thickness and higher material cost.
- **Steel moment frames** – not compatible with the existing precast wall system and would increase cost dramatically.
