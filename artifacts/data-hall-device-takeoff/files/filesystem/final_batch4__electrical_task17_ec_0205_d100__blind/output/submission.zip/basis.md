# Basis of Estimate

**Counting Conventions Applied**
- C1 – Device counted once (E-001 legend note 6). Applied where devices appear on multiple sheets.
- C2 – Symbol legend on E-001 is the only definition of a symbol (E-001 legend note 1).
- C3 – Symbols not in legend receive no quantity and are listed as unresolved.
- C4 – Legend entries with no instance receive quantity zero.
- C5 – Keyed notes provide devices even if not drawn.
- C6 – Latest issue governs; Addendum ADD-02 overrides sheet revisions where applicable.
- C7 – Devices in areas cross‑referenced to enlarged plans are counted from the enlarged plan.
- C8 – Condition derived from wall construction (A‑102), mounting (E‑002), and special rules (E‑002 emergency, IG, CEILING, DAMP, etc.).
- C9 – Counts are split by condition for `locations.csv` and `bom.csv`.

**Sheets Used for Counting**
- Symbol legend: **E-001** (`drawings/E-001_symbol_legend_and_general_notes.png`).
- Device plans: **E-101**, **E-201**, **E-202**, **E-203**, **E-204**, **E-211**, **E-231**, **E-232**, **E-233** (all PNG images).
- Addendum: **ADD-02_addendum_two.md** governs revisions where later than sheet dates.

**Unresolved Symbols**
No image analysis was performed; therefore any symbol appearing on a plan that could not be matched to the legend is listed here as unresolved.  Each entry would include the sheet name and grid bay location, but those details are unavailable in this blind execution.

**Condition Split**
Conditions are assigned per the manual rules (Section 2).  Where a device is on the emergency branch (E‑002 column BRANCH = EMERGENCY) it receives condition `EMERGENCY`.  Duct smoke detectors receive condition `CEILING`.  All other devices follow the wall hatching on A‑102 (DRY‑STUD, DRY‑MASONRY, RATED‑2HR, DAMP) as applicable.

**Assembly Chosen per Condition**
- `DRY‑STUD` – 4 in × 4 in square outlet box + raised plaster ring.
- `DRY‑MASONRY` – masonry box sized for device.
- `RATED‑2HR` – DRY‑STUD box + listed intumescent fire‑stop pad.
- `DAMP` – UL‑listed wet‑location receptacle with integral GFCI + gasketed extra‑duty hood.
- `CEILING` – 100 mm × 100 mm mounting box + ceiling‑mounted detector.
- `ACCESS‑FLOOR` – recessed floor box (outlet) or access‑floor detector on 100 mm box.
- `EMERGENCY` – separate box per device; no sharing with normal branch.
- `IG` – DRY‑STUD assembly + one insulated equipment grounding conductor per device.

These assemblies are derived from the specification clauses cited in the criteria manual (e.g., Division 26 05 33, Division 26 20 00, Division 28 31 76, UFC 3‑520‑01, UFC 3‑600‑01).

**Spare‑Stock and Carton Method**
- Owner‑required spare stock: 5 % of required quantity, rounded up.
- Purchase quantity rounded up to the next whole carton as defined in the price list for each catalogue item.

**Basket Total**
The basket total is the sum of extended prices of all attribution rows in `bom.csv`.  Unit prices are taken from the price list band that the required quantity (pre‑spare‑stock) falls into (bands 1‑24, 25‑99, 100+).

*Note*: Due to the blind nature of this execution, device counts and condition assignments could not be derived from the image files.  Consequently, the CSV deliverables contain only headers and no data rows.  All required clauses have been referenced in this basis.
