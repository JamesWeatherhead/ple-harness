# Design Basis Narrative

**Governing Documents**
- Structural Design Criteria – Roof (EOR-DC‑RD‑01 Rev 2) – provides the load definitions, snow drift methodology, uplift zones, and deck design rules.
- UFC 3‑301‑01 (2022) – supplies the roof live load (20 psf) and the seismic importance factor and spectral accelerations.
- Lateral Analysis Report (LAT‑2026‑003 Rev 1) – supplies the roof‑level wind forces, braced‑frame stiffnesses, and the diaphragm design force (FPX).
- Nordeck B‑36 Deck Catalogue (2026) – provides the allowable uniform total loads, diaphragm shear strengths (Sn) and stiffnesses (G′) for each sheet‑gage, support‑fastener pattern and sidelap connector count.
- Site‑specific Snow Case Study (SNOW‑2026‑014) – gives the ground snow load *pg* = 63 psf.

**Snow Load Basis**
- Ground snow load *pg* = 63 psf (Clause 5.1, EOR‑DC‑RD‑01).
- Exposure factor *Ce* = 0.90 (Clause 5.1).
- Thermal factor *Ct* = 1.00 (Clause 5.1).
- Snow importance factor *Is* = 1.10 (Clause 2.1).
- Flat‑roof snow load *pf* = 0.7·Ce·Ct·Is·pg = 43.66 psf (Clause 5.1).
- Snow density *γ* = 0.13·pg + 14 = 22.19 pcf (Clause 5.2).
- Balanced snow depth *hb* = pf/γ = 1.968 ft.

**Live‑Load Basis**
- Roof live load *Lr* = 20 psf (UFC 3‑301‑01 Table E‑1, Clause 4.1).
- No tributary‑area reduction because the panel area (3 ft × 6 ft) < 200 ft² (Clause 4.2).

**Wind & Uplift**
- Basic wind speed *V* = 115 mph, exposure C, height 32 ft (Clause 6.1).
- Velocity pressure *qh* = 29.93 psf (Clause 6.1).
- Net uplift pressures for the four pressure zones are taken from Table 6‑2 (e.g., Zone 3 = ‑101.2 psf). The deck attachment must resist the most severe pressure zone that intersects the zone.

**Seismic**
- SDS = 0.44, Seismic importance *Ie* = 1.25, R = 3.25 (Clause 7.1).
- Effective seismic weight = 18 psf (dead) + 0.2·*pf* = 26.732 psf (Clause 7.2).
- Seismic response coefficient *Cs* = SDS·Ie/R = 0.1692.
- Base shear *V* = Cs·W = 0.1692 × 26.732 psf × 43200 ft² ≈ 195.5 kip (Section 5.1 of the lateral report).
- Diaphragm design force *FPX* = 195.5 kip (Section 5.1, LAT‑2026‑003).

**Deck Zoning**
The roof is divided into nine axis‑aligned rectangles that align with the 6 ft joist spacing and the 6 ft sidelap module.  A 12 ft “zone width” (*a*) from Clause 6.2 defines four pressure zones; a 12 ft band is an integer multiple of the joist spacing, so all rectangle edges fall on valid grid lines.
- Corner zones (Z1‑Z4) – highest uplift – use 16 gage sheet (Sn = 1809 plf, G′ = 46.6 kip/in) and a 36/9 fastener pattern to obtain an uplift capacity of 151 psf > ‑101 psf.
- All other zones (Z5‑Z9) use 18 gage sheet (Sn = 1751 plf, G′ = 45.6 kip/in) with the same 36/9 pattern; uplift capacity ≈ 119.8 psf satisfies the remaining pressure zones.
- The 36/9 pattern provides the smallest tributary area per fastener, maximising uplift capacity while staying within the constructability limits (≤ 12 gage types, ≤ 3 attachment patterns, ≤ 12 zones).

**Diaphragm Classification**
The in‑plane diaphragm deflection for the most demanding case (seismic X, amplified collectors) is 1.0 in, which is less than 2 × storey drift (0.015 × 32 ft ≈ 5.8 in). Therefore the diaphragm is classified **Semi‑Rigid** (Clause 9.3).

**Cost Considerations**
Only two sheet‑gages are used (16 gage for corners, 18 gage elsewhere) and a single attachment pattern (36/9 with four SCREW‑10 sidelap connectors per span). This satisfies all hard constraints while minimizing material cost per the cost‑plan rates.
