# Design Basis Narrative

The roof deck design follows the **Structural Design Criteria – Roof (EOR-DC-RD-01 Rev 2)** and the **Lateral Analysis Report (LAT-2026-003)**.  Key governing clauses extracted:

* **Snow load** – Clause 5.1 defines the flat‑roof snow load *pf* = 0.7 · Ce · Ct · Is · pg = **43.66 psf** with pg = **63 psf** (ground snow load) from the site‑specific case study SNOW‑2026‑014.  Exposure factor Ce = **0.90**, thermal factor Ct = **1.0**, importance factor Is = **1.10**.
* **Snow density** – Clause 5.2 gives γ = 0.13 pg + 14 = **22.19 pcf**.
* **Balanced snow depth** – Clause 5.3 gives hb = pf/γ = **1.968 ft**.
* **Roof live load** – Clause 4.2 states the un‑reduced live load **Lr = 20 psf** (UFC 3‑301‑01 Table E‑1 item 51).  No tributary‑area reduction applies because the panel area (3 ft × 6 ft) is < 200 ft².
* **Effective seismic weight** – Clause 7.2 combines a dead weight of **18 psf** with **20 % of the flat‑roof snow load** (since pf > 30 psf).  Thus Wₛₑᵢₛₘᵢc = 18 + 0.2·43.66 = **26.732 psf**.
* **Diaphragm force** – The lateral report (Table 4‑1) provides the roof‑level diaphragm forces: **118 kip** for wind along the X‑axis (normal to the 180 ft walls) and **152 kip** for wind along Y (normal to the 240 ft walls).  The same forces are used for the seismic cases.
* **Classification** – The diaphragm is classified **Semi‑rigid** per the lateral analysis.

Drift surcharges are taken from the equipment layout (MEP‑PH‑1, SCR‑N, PARAPET, RTU‑1) with peak values of 5–6 psf over the balanced snow surface.

All values are recorded in the **DesignBasis** sheet of `deck_design.xlsx` and the corresponding requirement rows are listed in `constraint_register.xlsx`.
