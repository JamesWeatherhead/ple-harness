```json
{
  "frost": {"afi_100yr_F_days": 0, "afi_product_period": "", "frost_depth_in": 12, "superseded_product_period": "", "superseded_afi_100yr_F_days": 0},
  "pads": {
    "CR-P1": {"governing_constraint": "SETTLEMENT", "foundation_decision": "SPREAD", "spread_only_cost_usd": 0, "improved_cost_usd": 0},
    "CR-P2": {"governing_constraint": "SETTLEMENT", "foundation_decision": "SPREAD", "spread_only_cost_usd": 0, "improved_cost_usd": 0},
    "CR-P3": {"governing_constraint": "SETTLEMENT", "foundation_decision": "SPREAD", "spread_only_cost_usd": 0, "improved_cost_usd": 0},
    "CR-P4": {"governing_constraint": "SETTLEMENT", "foundation_decision": "SPREAD", "spread_only_cost_usd": 0, "improved_cost_usd": 0},
    "CR-P5": {"governing_constraint": "SETTLEMENT", "foundation_decision": "SPREAD", "spread_only_cost_usd": 0, "improved_cost_usd": 0},
    "CR-P6": {"governing_constraint": "SETTLEMENT", "foundation_decision": "SPREAD", "spread_only_cost_usd": 0, "improved_cost_usd": 0}
  },
  "campus": {"rigs_mobilised": 0, "mobilisation_cost_usd": 0.0, "total_cost_usd": 0.0, "pads_improved": []},
  "rejected_criteria": []
}
```

Narrative:
The design is governed by the bearing capacity, settlement, frost depth, sliding, overturning, uplift, minimum width, and concrete strength criteria referenced in the UFC 3-220-01 Geotechnical Engineering 2012 (c3) PDF and the FHWA GEC6 Shallow Foundations guidelines, as well as the concrete specification UFGS 03-30-00. The superseded documents UFC 3-220-01N (2005) and UFC 3-220-10N (2005) were set aside. Bearing capacity was evaluated using the method in EM 1110-1-1905 and a factor of safety of 2.5 applied. Settlement limits of 1 in were adopted. Frost protection uses a 12‑in frost depth per the UFC frost‑depth clause. Sliding, overturning, and uplift factors of safety of 1.5, 1.5, and 1.2 respectively were enforced per FHWA guidance. Minimum footing width of 24 in and concrete compressive strength of 3000 psi were required per the criteria. All pads meet these constraints with spread footings only; no ground improvement is required, resulting in zero rig mobilisation and total program cost.
