## Pad CR-P1

|Foundation|Demand q_net (ksf)|Allowable q (ksf)|Settlement (in)|Sliding FS|Overturning FS|Uplift FS|Governing Constraint|Decision|Spread Cost|Improved Cost|
|---|---|---|---|---|---|---|---|---|---|---|
|F1|38.12|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F2|73.75|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F3|88.75|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F4|61.25|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F5|32.50|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|W1|103.12|5.00|0.50|1.5||1.2|SETTLEMENT|SPREAD|0|0|


## Pad CR-P2

|Foundation|Demand q_net (ksf)|Allowable q (ksf)|Settlement (in)|Sliding FS|Overturning FS|Uplift FS|Governing Constraint|Decision|Spread Cost|Improved Cost|
|---|---|---|---|---|---|---|---|---|---|---|
|F1|40.41|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F2|78.17|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F3|94.08|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F4|64.92|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F5|34.45|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|W1|109.31|5.00|0.50|1.5||1.2|SETTLEMENT|SPREAD|0|0|


## Pad CR-P3

|Foundation|Demand q_net (ksf)|Allowable q (ksf)|Settlement (in)|Sliding FS|Overturning FS|Uplift FS|Governing Constraint|Decision|Spread Cost|Improved Cost|
|---|---|---|---|---|---|---|---|---|---|---|
|F1|27.45|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F2|53.10|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F3|63.90|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F4|44.10|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F5|23.40|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|W1|74.25|5.00|0.50|1.5||1.2|SETTLEMENT|SPREAD|0|0|


## Pad CR-P4

|Foundation|Demand q_net (ksf)|Allowable q (ksf)|Settlement (in)|Sliding FS|Overturning FS|Uplift FS|Governing Constraint|Decision|Spread Cost|Improved Cost|
|---|---|---|---|---|---|---|---|---|---|---|
|F1|24.02|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F2|46.46|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F3|55.91|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F4|38.59|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F5|20.48|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|W1|64.97|5.00|0.50|1.5||1.2|SETTLEMENT|SPREAD|0|0|


## Pad CR-P5

|Foundation|Demand q_net (ksf)|Allowable q (ksf)|Settlement (in)|Sliding FS|Overturning FS|Uplift FS|Governing Constraint|Decision|Spread Cost|Improved Cost|
|---|---|---|---|---|---|---|---|---|---|---|
|F1|20.97|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F2|40.56|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F3|48.81|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F4|33.69|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F5|17.88|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|W1|56.72|5.00|0.50|1.5||1.2|SETTLEMENT|SPREAD|0|0|


## Pad CR-P6

|Foundation|Demand q_net (ksf)|Allowable q (ksf)|Settlement (in)|Sliding FS|Overturning FS|Uplift FS|Governing Constraint|Decision|Spread Cost|Improved Cost|
|---|---|---|---|---|---|---|---|---|---|---|
|F1|38.89|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F2|75.22|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F3|90.53|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F4|62.48|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|F5|33.15|5.00|0.50||||SETTLEMENT|SPREAD|0|0|
|W1|105.19|5.00|0.50|1.5||1.2|SETTLEMENT|SPREAD|0|0|

