# Design Basis

*Table 1 – Summary of Governing Documents*

| Document | Clause | Requirement | Value | Units | Items |
|---|---|---|---|---|---|
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2.pdf | 3.2 | Roof diaphragm shear stiffness target | 0.5 | kip/in | DeckZones |
| WT-2026-07_Boundary_Layer_Wind_Study.pdf | 5.1 | Design wind pressure coefficient Cp | 0.8 | - | ShearWalls |

*Table 2 – Conflict Resolutions*

- The 2024 architectural plan (A-101_Roof_Plan_RevC.dxf) is superseded by the 2026 federated model IFC; all geometry taken from IFC.
- The precast panel schedule Rev2 replaces the superseded Rev1 schedule; panel dimensions updated accordingly.

All other requirements were derived from the above documents.
