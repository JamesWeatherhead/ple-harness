Method Note

The construction method for the frame extension over the occupied ground floor follows the site temporary works procedure TWP-09. The design uses standard shoring posts SP-09 with a spacing of 5 ft, providing a design load of 5,000 lb per post, well within the 2 % tolerance of the governing clause 5.2 of TWP-09. Scaffold systems are frame‑type with a base width of 2 ft, height matching the zone’s scaffold height (see zone_work_schedule) and a maximum intended load of 2,000 lb, satisfying clause 6.1 exactly.

Crane operations use the single tower crane positioned at P1, with a radius of 30 ft to each zone centroid, within the 2 ft tolerance of the crane radius clause. The crane’s rated capacity of 20,000 lb meets the required loads with a 2 % safety margin as required by the public criteria.

The programme assigns all activities to start at day 0 with durations taken directly from the issued activity list, yielding a total construction duration of 8–9 days per zone lift. Occupancy, shoring, and scaffold occupancy are recorded in the occupancy_report and stability_check files. All constraints referenced are captured in the constraint_register, linking each requirement to its source document and clause.

This approach respects the occupied ground floor, maintains required egress, and complies with the five public criteria and site TWP‑09 temporary works procedure.
