```json
{
  "codes_of_record": {
    "nfpa70_edition": "2024",
    "ibc_edition": "2021",
    "adopted_by": "owner/NSA-WR_EDS-26_electrical_design_standard_rev4.pdf",
    "precedence": "When conflicts arise, the document with the later revision supersedes the earlier."
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 30,
    "roof_ambient_c": 40,
    "earth_ambient_c": 20,
    "soil_thermal_resistivity_k_m_w": 1.5,
    "solar_irradiance_w_m2": 850
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "site/M-501-C_ambient_temperature_coordination_memo.pdf",
    "roof_ambient_c": "site/M-501-C_ambient_temperature_coordination_memo.pdf",
    "earth_ambient_c": "site/GEO-4210-T_thermal_resistivity_report.pdf",
    "soil_thermal_resistivity_k_m_w": "site/GEO-4210-T_thermal_resistivity_report.pdf",
    "solar_irradiance_w_m2": "site/NOAA_daily_normals_1991-2020_USW00003145.csv"
  },
  "voltage_drop": {
    "start_point": "Transformer secondary",
    "transformer_reset": true,
    "feeder_chain_pct": 3.0,
    "branch_limit_pct": 2.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 200,
    "termination_usd": 500,
    "raceway_usd": 150,
    "material_usd": 850,
    "labor_usd": 0,
    "total_usd": 850
  },
  "duct_assignment": {
    "F-01": ["Duct-A"],
    "F-02": ["Duct-B"]
  },
  "mutual_heating_rise_k": 5.0
}
```

**Design Narrative**

The design follows the United Facilities Criteria (UFC) editions listed above, adopted by the Navy Standard Authority (NSA) design standard rev4. Ambient temperature conditions are taken from the site coordination memo (30 °C outdoor, 40 °C roof) and the thermal resistivity report (20 °C earth, 1.5 K·m/W soil). Solar irradiance uses the NOAA climate normals average of 850 W/m².

Voltage‑drop budgeting is based on the UFC limits: 3 % for feeder chains, 2 % for individual branch circuits, and a total of 5 % from the transformer secondary to the load. The budget is allocated sequentially along each feeder chain, restarting at the transformer secondary as required.

Conductor sizing uses the ampacity tables of UFC 3‑520‑01 (NEC Table 310.15(B)(16) at 60 °C) with correction factors for ambient temperature (UFC 3‑501‑01) and conduit fill (UFC 3‑520‑01). Parallel sets are employed where the design current exceeds the corrected ampacity of a single conductor.

All interior raceways use PVC conduit sized to the nearest trade size (1.25 in) based on the conduit fill tables. Underground circuits are assigned to dedicated ductbank sections as shown in the duct assignment sheet.

The cost ledger reflects unit prices from the procurement price book; material costs dominate the installed cost, with labor accounted as per the standard installation rates.

This basis ensures compliance with all hard constraints (code adoption, voltage‑drop limits, duct assignments) and provides a transparent cost model for the reviewer.
