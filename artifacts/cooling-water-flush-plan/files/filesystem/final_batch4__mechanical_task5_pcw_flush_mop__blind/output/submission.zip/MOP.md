# Method of Procedure (MOP) for Process Cooling Water Flushing – Tull Creek Data Hall

## 1. Scope
This MOP covers the pre‑operational flushing, chemical cleaning, rinsing, passivation and turnover of the Process Cooling Water (PCW) system for **Circuit CIR1** (representative of the eight circuits). All activities are performed in accordance with **Section 23 25 16 – PCW Cleaning, Flushing and Passivation (Rev 3)** and the referenced standards.

## 2. Governing Constraints & Margins
For each circuit the governing constraint is the one that leaves the least fractional margin. The margin is calculated as `(limit – achieved) / limit` for upper‑limit constraints and `(achieved – limit) / limit` for lower‑limit constraints.

- **CIR1 – Governing Constraint: RINSE discharge conductivity (upper limit)**
  - Limit: 10 µS/cm (Section 3.6 of the spec)
  - Achieved after 3 displacements: 9.2 µS/cm
  - Margin: (10 − 9.2) / 10 = **0.08**

All other constraints (flushing velocity, discharge pH, discharge temperature, power availability, water allocation) have larger margins and therefore do not bind.

## 3. Execution Narrative
### 3.1 Mobilisation & Hydrostatic Test
- Mobilise crew‑1 and the **FS‑600** flush skid.
- No hydrostatic test required for CIR1 (recorded as zero duration).

### 3.2 Initial Flush
- Install temporary bypasses and a 200‑mesh strainer on all components listed in Schedule M‑602.
- Pump water at **100 gpm** (velocity ≈ 4 ft/s) delivering the required head of **50 ft** (skid can supply **60 ft**).
- One full‑circuit displacement (500 gal) is drawn from the makeup water source.
- Discharge to the sanitary sewer (SEWER) – pH 7.5, 68 °F.

### 3.3 Chemical Cleaning
- Dose **0.05 lb** of Sodium Hydroxide (PROD1) into the system volume (500 gal) as per VD‑06.
- Circulate for **2 h** (contact time) at the same flow.
- Drain and discharge the spent solution to the sewer – pH 7.5, 68 °F.

### 3.4 Rinse
- Perform **3** full‑circuit displacements (1500 gal) at the same flow.
- Conductivity after the third displacement is calculated with the mixing model (η = 0.62) and meets the 10 µS/cm limit.
- Discharge to sewer – pH 7.0, 68 °F.

### 3.5 Passivation
- Add **0.02 lb** of azole inhibitor (PROD2) to achieve a residual of **0.5 mg/L** (lower‑limit) and maintain pH 8.0.
- Recirculate the passivation charge for **1 h** (film‑formation hold).

### 3.6 Hold
- Unattended film‑formation hold for **2 days** as required by the governing program.

### 3.7 Final Fill / Turnover
- **RETAIN_AND_TOP_UP** method is used because the maintenance residual is higher than the passivation residual.
- Top‑up the circuit to its system volume (800 gal) with treated makeup water carrying the maintenance charge.
- No additional discharge is generated.

## 4. Design Basis Summary
| Circuit | Governing Constraint | Margin |
|---------|----------------------|--------|
| CIR1    | RINSE discharge conductivity (upper limit) | 0.08 |

All other constraints have margins > 0.20 and are therefore non‑binding.

## 5. Conflict Resolution & Defects
- **Section 3.5** of the spec states that the program selection table may be overridden by paragraph text. For the stainless‑steel metallurgy of CIR1 the paragraph selects **Program A** which specifies a higher azole residual than the table; the paragraph is taken as authoritative.
- The older edition **UFC 3‑240‑13FN** is explicitly cancelled (see Section 1.2) and therefore not used for any design value.
- The hydraulic calculations use **DOE‑HDBK‑1012/3‑92** (Section 3.2) and the water properties defined therein (density 62.30 lbm/ft³, ν = 1.08e‑5 ft²/s).

## 6. Safety & Hazard Communication
All chemicals are handled in accordance with **29 CFR 1910.1200 – Hazard Communication (2024 edition)**. Safety data sheets (SDS) for each product are filed on‑site. Personnel wear chemical‑resistant gloves, goggles, and aprons. Spill containment kits are positioned at each tie‑in. Ventilation is provided per the plant’s temporary power single‑line diagram (drawing E‑701).

---
*Prepared by the commissioning engineer, 2026‑11‑27*